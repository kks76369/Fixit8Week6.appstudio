var names = ["Bob", "Janet", "Tom", "Bob", "Randy", "Elizabeth", "Kim", "Nancy"];
  for (var i = names.length - 1; i >= 0; i--) {
     console.log(names[i])
}