//calc

function summedNumber(num1, num2) {
   let answer = num1 + num2
   return answer
}
let number1 = parseInt(prompt("Number One"))
let number2 = parseInt(prompt("Number Two"))
let newAnswer = summedNumber(number1, number2)
alert(`The sum of ${number1} and ${number1} is ${newAnswer}.`)
